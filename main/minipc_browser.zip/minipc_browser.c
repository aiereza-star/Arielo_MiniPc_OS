// minipc_browser.c
// Mini-navegador grafico para la MiniPC. Descarga una URL (HTTP plano, via
// breezy_http_download) y parsea el HTML a texto legible (sin tags), para
// mostrarlo en una ventana del escritorio con scroll.
//
// El parseo es deliberadamente simple pero efectivo:
//   - elimina tags <...>
//   - <p> <br> <h1..6> <li> <tr> <div> => salto de linea
//   - decodifica entidades comunes (&amp; &lt; &gt; &quot; &nbsp; &#NN;)
//   - colapsa espacios y lineas en blanco repetidas
//   - ignora por completo <script> y <style> (su contenido no es texto util)

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_heap_caps.h"

#include "minipc_browser.h"
#include "breezybox.h"
#include "esp_http_client.h"
#include "esp_netif.h"

// Timeout de descarga en ms. Bajado de 30s (el de breezy_http_download) a 10s
// para que un fallo se detecte rapido y no parezca que la UI se cuelga.
#define BROWSER_HTTP_TIMEOUT_MS  10000

// Contexto de descarga: escribe el cuerpo HTTP al fichero.
typedef struct { FILE *file; size_t total; } dl_ctx_t;

static esp_err_t browser_http_event(esp_http_client_event_t *evt)
{
    dl_ctx_t *ctx = (dl_ctx_t *)evt->user_data;
    if (evt->event_id == HTTP_EVENT_ON_DATA && ctx && ctx->file && evt->data_len > 0) {
        ctx->total += fwrite(evt->data, 1, evt->data_len, ctx->file);
    }
    return ESP_OK;
}

static int browser_has_network(void)
{
    esp_netif_t *netif = esp_netif_get_default_netif();
    if (!netif) return 0;
    esp_netif_ip_info_t ip;
    if (esp_netif_get_ip_info(netif, &ip) != ESP_OK) return 0;
    return ip.ip.addr != 0;
}

// Descarga 'url' a 'dest_path' con timeout corto. Devuelve 0 si OK.
static int browser_download(const char *url, const char *dest_path)
{
    if (!url || !dest_path) return -1;
    if (!browser_has_network()) return -2;

    FILE *f = fopen(dest_path, "wb");
    if (!f) return -1;

    dl_ctx_t ctx = { .file = f, .total = 0 };
    esp_http_client_config_t cfg = {
        .url = url,
        .event_handler = browser_http_event,
        .user_data = &ctx,
        .timeout_ms = BROWSER_HTTP_TIMEOUT_MS,   // <-- 10s en vez de 30s
        .max_redirection_count = 5,
        .buffer_size = 4096,
        .buffer_size_tx = 2048,
    };
    esp_http_client_handle_t client = esp_http_client_init(&cfg);
    if (!client) { fclose(f); unlink(dest_path); return -1; }

    esp_http_client_set_header(client, "User-Agent", "ESP32-BreezyBox");
    esp_err_t err = esp_http_client_perform(client);
    int status = esp_http_client_get_status_code(client);
    esp_http_client_cleanup(client);
    fclose(f);

    if (err != ESP_OK || (status != 200 && status != 0)) {
        unlink(dest_path);
        return -1;
    }
    return 0;
}

static const char *TAG = "minipc_browser";

// strcasestr portable (newlib de ESP-IDF no siempre lo trae)
static char *bz_strcasestr(const char *haystack, const char *needle)
{
    size_t nl = strlen(needle);
    if (nl == 0) return (char *)haystack;
    for (; *haystack; haystack++) {
        if (strncasecmp(haystack, needle, nl) == 0) return (char *)haystack;
    }
    return NULL;
}

// Descarga a este fichero temporal (SD si esta montada, si no LittleFS)
#define BROWSER_TMP_PATH   "/sdcard/.browser_tmp.html"
#define BROWSER_TMP_ALT    "/littlefs/.browser_tmp.html"

// Limites de memoria
#define RAW_MAX     (96 * 1024)   // HTML crudo maximo
#define TEXT_MAX    (48 * 1024)   // texto parseado maximo
#define MAX_LINES   2000

// breezy_http_download viene de breezybox.h (firmware)

static char *s_raw  = NULL;       // HTML crudo
static char *s_text = NULL;       // texto parseado
static int   s_text_len = 0;
static int  *s_line_off = NULL;   // offset de inicio de cada linea en s_text
static int   s_line_count = 0;

static browser_state_t s_state = BROWSER_IDLE;
static char s_status[96] = "Escribe una URL y pulsa Enter";

void minipc_browser_init(void)
{
    if (!s_raw)      s_raw  = heap_caps_malloc(RAW_MAX,  MALLOC_CAP_SPIRAM);
    if (!s_text)     s_text = heap_caps_malloc(TEXT_MAX, MALLOC_CAP_SPIRAM);
    if (!s_line_off) s_line_off = heap_caps_malloc(MAX_LINES * sizeof(int), MALLOC_CAP_SPIRAM);
    if (!s_raw || !s_text || !s_line_off) {
        ESP_LOGE(TAG, "Sin memoria para buffers del navegador");
    }
    s_state = BROWSER_IDLE;
}

// --- Decodificacion de entidades HTML comunes ---
// Devuelve el char decodificado y avanza *pp tras el ';'. Si no reconoce,
// devuelve 0 y no avanza.
static char decode_entity(const char **pp)
{
    const char *p = *pp;       // apunta al '&'
    const char *semi = strchr(p, ';');
    if (!semi || (semi - p) > 10) return 0;

    int len = semi - p - 1;    // longitud del nombre entre & y ;
    const char *name = p + 1;

    struct { const char *n; char c; } table[] = {
        {"amp", '&'}, {"lt", '<'}, {"gt", '>'}, {"quot", '"'},
        {"apos", '\''}, {"nbsp", ' '}, {"middot", '*'}, {"hellip", '.'},
        {"mdash", '-'}, {"ndash", '-'}, {"copy", 'c'}, {"reg", 'r'},
        {"trade", 't'}, {"deg", 'o'},
    };
    for (size_t i = 0; i < sizeof(table)/sizeof(table[0]); i++) {
        if ((int)strlen(table[i].n) == len && strncmp(name, table[i].n, len) == 0) {
            *pp = semi + 1;
            return table[i].c;
        }
    }
    // Entidad numerica &#NN; o &#xHH;
    if (name[0] == '#') {
        int code;
        if (name[1] == 'x' || name[1] == 'X') code = (int)strtol(name + 2, NULL, 16);
        else code = atoi(name + 1);
        *pp = semi + 1;
        if (code >= 32 && code < 127) return (char)code;  // ASCII imprimible
        if (code == 160) return ' ';                       // nbsp
        return '?';   // no-ASCII: marcador (Fase 2 seria UTF-8)
    }
    return 0;
}

// Devuelve 1 si el tag (nombre en minusculas) fuerza salto de linea.
static int tag_is_block(const char *tag, int len)
{
    static const char *blocks[] = {
        "p","br","div","h1","h2","h3","h4","h5","h6",
        "li","tr","ul","ol","table","section","article",
        "header","footer","title","hr",
    };
    for (size_t i = 0; i < sizeof(blocks)/sizeof(blocks[0]); i++) {
        int bl = strlen(blocks[i]);
        if (bl == len && strncasecmp(tag, blocks[i], len) == 0) return 1;
    }
    return 0;
}

// Parsea s_raw (HTML) -> s_text (texto limpio). Construye indice de lineas.
static void parse_html_to_text(void)
{
    const char *src = s_raw;
    char *out = s_text;
    int out_len = 0;
    int last_was_space = 1;     // para colapsar espacios
    int newline_run = 0;        // para colapsar lineas en blanco

    while (*src && out_len < TEXT_MAX - 2) {

        // Saltar bloques <script>...</script> y <style>...</style> enteros
        if (strncasecmp(src, "<script", 7) == 0) {
            const char *end = bz_strcasestr(src, "</script>");
            src = end ? end + 9 : src + strlen(src);
            continue;
        }
        if (strncasecmp(src, "<style", 6) == 0) {
            const char *end = bz_strcasestr(src, "</style>");
            src = end ? end + 8 : src + strlen(src);
            continue;
        }
        // Comentarios <!-- ... -->
        if (strncmp(src, "<!--", 4) == 0) {
            const char *end = strstr(src, "-->");
            src = end ? end + 3 : src + strlen(src);
            continue;
        }

        if (*src == '<') {
            // Leer nombre de tag (saltando '/')
            const char *t = src + 1;
            int closing = 0;
            if (*t == '/') { closing = 1; t++; }
            const char *name = t;
            int nlen = 0;
            while (t[nlen] && (isalnum((unsigned char)t[nlen]))) nlen++;

            int is_block = tag_is_block(name, nlen);
            (void)closing;

            // Avanzar hasta cerrar '>'
            const char *gt = strchr(src, '>');
            src = gt ? gt + 1 : src + strlen(src);

            if (is_block) {
                // Forzar salto de linea (colapsando repetidos)
                if (newline_run < 2 && out_len > 0) {
                    out[out_len++] = '\n';
                    newline_run++;
                    last_was_space = 1;
                }
            }
            continue;
        }

        char c;
        if (*src == '&') {
            const char *p = src;
            char dec = decode_entity(&p);
            if (dec) { c = dec; src = p; }
            else { c = '&'; src++; }
        } else {
            c = *src++;
        }

        // Normalizar espacios/tabs/saltos en un solo espacio
        if (c == '\r' || c == '\n' || c == '\t') c = ' ';

        if (c == ' ') {
            if (last_was_space) continue;   // colapsar
            last_was_space = 1;
        } else {
            last_was_space = 0;
            newline_run = 0;
        }

        out[out_len++] = c;
    }

    out[out_len] = '\0';
    s_text_len = out_len;

    // Construir indice de lineas
    s_line_count = 0;
    s_line_off[s_line_count++] = 0;
    for (int i = 0; i < out_len && s_line_count < MAX_LINES; i++) {
        if (s_text[i] == '\n') {
            s_text[i] = '\0';   // terminar la linea para poder devolver punteros
            if (i + 1 < out_len) s_line_off[s_line_count++] = i + 1;
        }
    }
}

void minipc_browser_load(const char *url)
{
    if (!s_raw || !s_text || !s_line_off) {
        s_state = BROWSER_ERROR;
        snprintf(s_status, sizeof(s_status), "Sin memoria");
        return;
    }

    s_state = BROWSER_LOADING;
    snprintf(s_status, sizeof(s_status), "Descargando %s ...", url);
    ESP_LOGI(TAG, "GET %s", url);

    // Descargar a fichero temporal
    const char *tmp = BROWSER_TMP_PATH;
    int rc = browser_download(url, tmp);
    if (rc != 0) {
        // probar ruta alternativa (por si /sdcard no esta montado)
        tmp = BROWSER_TMP_ALT;
        rc = browser_download(url, tmp);
    }
    if (rc != 0) {
        s_state = BROWSER_ERROR;
        snprintf(s_status, sizeof(s_status), "Error de descarga (HTTP/red). Solo http://");
        return;
    }

    // Leer el fichero a s_raw
    s_state = BROWSER_RENDERING;
    snprintf(s_status, sizeof(s_status), "Procesando pagina...");
    FILE *f = fopen(tmp, "rb");
    if (!f) {
        s_state = BROWSER_ERROR;
        snprintf(s_status, sizeof(s_status), "No pude abrir la descarga");
        return;
    }
    int n = fread(s_raw, 1, RAW_MAX - 1, f);
    fclose(f);
    remove(tmp);
    if (n <= 0) {
        s_state = BROWSER_ERROR;
        snprintf(s_status, sizeof(s_status), "Pagina vacia");
        return;
    }
    s_raw[n] = '\0';

    parse_html_to_text();

    s_state = BROWSER_DONE;
    snprintf(s_status, sizeof(s_status), "Listo: %d lineas, %d bytes", s_line_count, n);
}

browser_state_t minipc_browser_state(void) { return s_state; }
const char *minipc_browser_status_text(void) { return s_status; }

// Pone el estado en LOADING con un mensaje, para pintarlo ANTES de la descarga
// bloqueante (que congela el bucle de la UI).
void minipc_browser_set_loading(const char *url)
{
    s_state = BROWSER_LOADING;
    snprintf(s_status, sizeof(s_status), "Descargando %s ...", url);
}
const char *minipc_browser_text(void) { return s_text ? s_text : ""; }
int minipc_browser_line_count(void) { return s_line_count; }

const char *minipc_browser_get_line(int n, int *out_len)
{
    if (n < 0 || n >= s_line_count) { if (out_len) *out_len = 0; return ""; }
    const char *line = s_text + s_line_off[n];
    if (out_len) *out_len = strlen(line);
    return line;
}
