#pragma once
#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// Estado del mini-navegador
typedef enum {
    BROWSER_IDLE = 0,     // esperando URL
    BROWSER_LOADING,      // descargando
    BROWSER_RENDERING,    // parseando
    BROWSER_DONE,         // contenido listo para mostrar
    BROWSER_ERROR,        // fallo (ver browser_status_text)
} browser_state_t;

// Inicializa el navegador (buffers). Llamar una vez.
void minipc_browser_init(void);

// Lanza la descarga + parseo de 'url'. Bloqueante (corre la descarga).
// Al volver, el estado queda en BROWSER_DONE o BROWSER_ERROR.
void minipc_browser_load(const char *url);

// Pone estado LOADING + mensaje, para pintar ANTES de la descarga bloqueante.
void minipc_browser_set_loading(const char *url);

browser_state_t minipc_browser_state(void);

// Texto de estado legible (para la barra: "Descargando...", "Error: ...", etc.)
const char *minipc_browser_status_text(void);

// Acceso al texto ya parseado (limpio, sin tags). Lineas separadas por '\n'.
const char *minipc_browser_text(void);

// Numero total de lineas del texto parseado (para el scroll).
int minipc_browser_line_count(void);

// Devuelve el puntero al inicio de la linea 'n' y su longitud (sin '\n').
// Para que el visor pinte linea a linea con scroll.
const char *minipc_browser_get_line(int n, int *out_len);

#ifdef __cplusplus
}
#endif
